<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author F. Mueller-Donath <j.felix@mueller-donath.de>
 * @author e-dschungel <github@e-dschungel.de>
 */
$lang['allowrename']           = 'Umbenennen von Seiten diesen Gruppen und Benutzern erlauben (durch Kommas getrennt).';
$lang['minor']                 = 'Linkanpassung als kleine Änderung markieren? Kleine Änderung werden in RSS Feeds und Benachrichtigungsmails nicht aufgeführt.';
$lang['autoskip']              = 'Automatisches Überspringen von Fehlern beim Verschieben von Namensräumen standardmäßig aktivieren. ';
$lang['autorewrite']           = 'Automatische Linkanpassung standardmäßig aktivieren.';
$lang['pagetools_integration'] = 'Umbenennen-Button zu Pagetools hinzufügen';
