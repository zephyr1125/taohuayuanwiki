<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Fábio Nogueira <fnogueira@gnome.org>
 */
$lang['notexist']              = 'A página %s não existe';
$lang['norights']              = 'Você tem permissões insuficientes para editar %s';
$lang['medianotexist']         = 'O arquivo de mídia %s não existe';
$lang['btn_start']             = 'Iniciar';
$lang['btn_continue']          = 'Continuar';
