<?php

$conf['allowrename'] = '@user';
$conf['minor'] = 1;
$conf['autoskip'] = 0;
$conf['autorewrite'] = 1;
$conf['pagetools_integration'] = 1;
