<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Esther Brunner <wikidesign@gmail.com>
 */
$lang['readmore']              = '→ Weiterlesen...';
