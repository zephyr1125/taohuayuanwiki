<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Soren Birk <soer9648@eucl.dk>
 */
$lang['readmore']              = '→ Læs mere...';
