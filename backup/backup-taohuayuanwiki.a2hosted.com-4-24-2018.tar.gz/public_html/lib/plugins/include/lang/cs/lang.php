<?php
/**
 * Czech language file (UTF-8 encoding)
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Lukas Zapletal <lukas.zapletal at gmail dot com>
 */

// custom language strings for the plugin
$lang['readmore']   = '→ Číst dále...';

//Setup VIM: ex: et ts=2 :
