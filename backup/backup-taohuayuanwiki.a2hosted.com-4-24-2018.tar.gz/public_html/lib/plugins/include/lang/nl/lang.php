<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Gijs H. van Gemert <g.v.gemert@inter.nl.net>
 */
$lang['readmore']              = '→ Lees verder...';
