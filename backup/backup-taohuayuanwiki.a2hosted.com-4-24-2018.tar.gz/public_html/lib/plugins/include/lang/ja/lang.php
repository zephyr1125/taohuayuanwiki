<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Satoshi Sahara <sahara.satoshi@gmail.com>
 */
$lang['readmore']              = '→ 続き...';
