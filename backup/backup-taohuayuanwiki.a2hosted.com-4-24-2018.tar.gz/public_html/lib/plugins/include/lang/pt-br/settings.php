<?php
/**
 * Portuguese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Flávio Roberto Santos <flavio.barata@gmail.com>
 */
 
// for the configuration manager
$lang['firstseconly']     = 'mostrar apenas primeira seção de registros do blog';
$lang['showdate']         = 'mostrar datas abaixo dos registros do blog';
$lang['showuser']         = 'mostrar usernames abaixo dos registros do blog';

//Setup VIM: ex: et ts=2 :
