<?php
/**
 * Portuguese language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Esther Brunner <wikidesign@gmail.com>
 * @author     Fernando Ribeiro <pinguim.ribeiro@gmail.com>
 */

// custom language strings for the plugin
$lang['readmore']   = '→ Ler mais...';

//Setup VIM: ex: et ts=2 :
