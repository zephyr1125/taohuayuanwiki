<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['readmore']              = '→ Legi plu...';
