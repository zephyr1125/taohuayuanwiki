<?php
/**
 * Slovenian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Blaž Mertelj <Blaz.Mertelj@atol.si>
 */

// custom language strings for the plugin
$lang['readmore']   = '→ Preberi več...';

//Setup VIM: ex: et ts=2 :