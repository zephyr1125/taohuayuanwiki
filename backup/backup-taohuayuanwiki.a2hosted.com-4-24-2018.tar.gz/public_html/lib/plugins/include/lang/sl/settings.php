<?php
/**
 * Slovenian language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Blaž Mertelj <Blaz.Mertelj@atol.si>
 */
 
// for the configuration manager
$lang['firstseconly']       = 'prikaži samo prvo sekcijo blog vnosov';

$lang['showlink']      = 'prikaži permalinke pod blog vnosi';
$lang['showdate']      = 'prikaži datume pod blog vnosi';
$lang['showuser']      = 'prikaži uporabniška imena pod blog vnosi';

//Setup VIM: ex: et ts=2 :