<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Spike <Spike@Foobar2000.Ru>
 * @author Aleksandr Selivanov <alexgearbox@gmail.com>
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['readmore']              = 'Читать дальше...';
