<?php
/**
* Arabic language file
*
* @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
* @author    Muhammad Bashir Al-Noimi <bashir.storm@gmail.com>
*            http://www.hali-sy.com
*/

// custom language strings for the plugin
$lang['readmore']   = ' ←إقرأ المزيد... ';

