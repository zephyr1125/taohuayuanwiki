<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Damien Raude-Morvan <drazzib@drazzib.com>
 */
$lang['readmore']              = 'Lire la suite...';
