<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author lainme <lainme993@gmail.com>
 */
$lang['readmore']              = '→ 阅读更多...';
