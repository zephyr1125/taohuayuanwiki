<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Norbert Csík <norbert.csik@gmail.com>
 * @author DelD <deldadam@gmail.com>
 */
$lang['readmore']              = 'Tovább...';
