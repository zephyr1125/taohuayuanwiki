<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Christer Nygren <wiki@fronet.fro.se>
 */
$lang['readmore']              = '→ Läs mer...';
