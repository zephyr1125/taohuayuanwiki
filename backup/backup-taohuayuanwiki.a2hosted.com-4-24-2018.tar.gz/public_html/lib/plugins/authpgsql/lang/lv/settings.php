<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['password']              = 'Lietotāja parole';
$lang['delUser']               = 'SQL pieprasījums lietotāja dzēšanai';
