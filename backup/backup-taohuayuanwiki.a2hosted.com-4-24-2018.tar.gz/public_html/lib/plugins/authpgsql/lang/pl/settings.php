<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Mati <mackosa@wp.pl>
 */
$lang['server']                = 'Twój serwer PostgreSQL';
$lang['database']              = 'Baza danych do użycia';
