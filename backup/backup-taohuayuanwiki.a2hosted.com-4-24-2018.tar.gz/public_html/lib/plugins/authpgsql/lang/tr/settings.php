<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author İlker R. Kapaç <irifat@gmail.com>
 */
$lang['server']                = 'PostgreSQL sunucunuz';
$lang['port']                  = 'PostgreSQL sunucunuzun kapısı (port)';
$lang['user']                  = 'PostgreSQL kullanıcısının adı';
$lang['password']              = 'Yukarıdaki kullanıcı için şifre';
$lang['database']              = 'Kullanılacak veritabanı';
$lang['debug']                 = 'İlave hata ayıklama bilgisini görüntüle';
