## Hiddenheader plugin for DokuWiki

Documentation may be found at: http://dokuwiki.org/plugin:hiddenheader


----
Copyright (C) 2011 Eli Fenton

This program is free software. It may be redistributed and modified under the
terms of the GNU General Public License version 2. This program is distributed without
any warranty.
