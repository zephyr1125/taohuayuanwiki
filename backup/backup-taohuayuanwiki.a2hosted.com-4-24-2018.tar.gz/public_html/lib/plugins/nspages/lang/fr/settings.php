<?php

$lang['cache'] = 'Désactive le cache';
$lang['default_picture'] = 'Image par défaut';
$lang['toolbar_inserted_markup'] = 'Markup inséré par la barre d\'outils';
