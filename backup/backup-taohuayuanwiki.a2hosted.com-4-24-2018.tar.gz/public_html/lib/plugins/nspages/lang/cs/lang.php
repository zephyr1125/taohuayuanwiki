<?php
/**
 * Czech language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Jan Müller muller.jan@gmail.com
 */
 
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'tato kategorie neexistuje: ';
$lang['subcats']               = 'Podkategorie:';
$lang['pagesinthiscat']        = 'Stránky v této kategorii:';
$lang['continued']             = ' pokr.';
$lang['nopages']               = 'Žádné stránky v této kategorii.';
$lang['nosubns']               = 'Není žádná podkategorie.';
