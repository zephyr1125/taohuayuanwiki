<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Hideaki SAWADA <chuno@live.jp>
 */
$lang['cache']                 = 'キャッシュを無効にする。';
$lang['toolbar_inserted_markup'] = '構文を挿入するツールバー';
