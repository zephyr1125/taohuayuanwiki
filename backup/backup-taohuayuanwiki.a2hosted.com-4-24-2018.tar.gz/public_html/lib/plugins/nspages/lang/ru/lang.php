<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Alexey Markov <redrat@mail.ru>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'Этот раздел не существует: ';
$lang['subcats']               = 'Подразделы:';
$lang['pagesinthiscat']        = 'Страницы в этом разделе:';
$lang['continued']             = ' (продолжение)';
$lang['nopages']               = 'Нет страниц в этом разделе.';
$lang['nosubns']               = 'Нет подразделов.';
