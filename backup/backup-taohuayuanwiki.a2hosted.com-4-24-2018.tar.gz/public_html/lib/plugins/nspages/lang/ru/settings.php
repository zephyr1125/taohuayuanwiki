<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 */
$lang['cache']                 = 'Отключить кэширование';
$lang['toolbar_inserted_markup'] = 'Разметка для вставки через кнопку на панели инструментов страницы';
