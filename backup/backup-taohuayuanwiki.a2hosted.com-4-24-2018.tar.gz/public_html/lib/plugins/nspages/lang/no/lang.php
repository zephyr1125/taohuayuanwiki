<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'dette navnerommet fins ikke:';
$lang['subcats']               = 'Undernavnerom:';
$lang['pagesinthiscat']        = 'Sider i dette navnerommet:';
$lang['continued']             = 'forts.';
$lang['nopages']               = 'Ingen sider i dette navnerommet.';
$lang['nosubns']               = 'Ingen undernavnerom.';
