<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Padhie <develop@padhie.de>
 */
$lang['cache']                 = 'Cache deaktivieren';
$lang['toolbar_inserted_markup'] = 'Toolbar eingefügtes markup';
