<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Robert Bogenschneider <bogi@uea.org>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'tiu nomspaco ne ekzistas:';
$lang['subcats']               = 'Subnomspaco:';
$lang['pagesinthiscat']        = 'Paĝoj en tiu nomspaco:';
$lang['continued']             = 'pli';
$lang['nopages']               = 'Neniuj paĝoj en tiu nomspaco.';
$lang['nosubns']               = 'Neniu subnomspaco.';
