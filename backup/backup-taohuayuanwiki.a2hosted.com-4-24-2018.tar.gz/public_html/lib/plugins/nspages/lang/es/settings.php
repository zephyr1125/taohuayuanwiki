<?php

$lang['cache'] = 'Deshabilitar cache';
$lang['toolbar_inserted_markup'] = 'Texto al utilizar botón de herramientas';
