<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Erial <erial2@gmail.com>
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['cache']                 = '캐시를 비활성화';
$lang['toolbar_inserted_markup'] = '마크업이 삽입된 툴바';
