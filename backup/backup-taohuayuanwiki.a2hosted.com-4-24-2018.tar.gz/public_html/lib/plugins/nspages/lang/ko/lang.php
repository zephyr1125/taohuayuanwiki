<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = '이 이름공간은 존재하지 않습니다:';
$lang['subcats']               = '하위 이름공간:';
$lang['pagesinthiscat']        = '이 이름공간에 있는 문서:';
$lang['continued']             = '(계속)';
$lang['nopages']               = '이 이름공간에 문서가 없습니다.';
$lang['nosubns']               = '하위 이름공간이 없습니다.';
