<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Sam01 <m.sajad079@gmail.com>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'این فضای‌نام وجود ندارد:';
$lang['subcats']               = 'فضای‌نام‌های فرعی:';
$lang['pagesinthiscat']        = 'صفحات در این فضای‌نام:';
$lang['continued']             = 'ادامه.';
$lang['nopages']               = 'صفحه‌ای در این فضای‌نام نیست.';
$lang['nosubns']               = 'بدون فضای‌نام‌های فرعی.';
