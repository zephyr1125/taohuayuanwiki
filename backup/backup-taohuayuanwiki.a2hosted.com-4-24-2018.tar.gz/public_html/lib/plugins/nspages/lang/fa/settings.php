<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Sam01 <m.sajad079@gmail.com>
 * @author Ghassem Tofighi <ghassem@gmail.com>
 */
$lang['cache']                 = 'غیرفعال کردن کش ';
$lang['default_picture'] = 'درج تصویر پیش‌فرض';
$lang['toolbar_inserted_markup'] = 'درج نشانه‌گذار نوار ابزار';

