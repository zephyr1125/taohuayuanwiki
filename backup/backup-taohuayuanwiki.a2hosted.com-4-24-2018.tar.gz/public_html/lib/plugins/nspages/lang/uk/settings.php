<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Oleksiy <alexey.furashev@gmail.com>
 */
$lang['cache']                 = 'Заборонити кешування';
$lang['toolbar_inserted_markup'] = 'Розмітка вставлена з Панелі інструментів (toolbar)';
