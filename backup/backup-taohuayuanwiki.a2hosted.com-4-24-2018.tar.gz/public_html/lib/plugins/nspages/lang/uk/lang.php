<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Oleksiy <alexey.furashev@gmail.com>
 */
$lang['doesntexist']           = 'цього простору назв немає:';
$lang['subcats']               = 'Вкладені простори назв';
$lang['pagesinthiscat']        = 'Сторінок в просторі назв';
$lang['continued']             = 'кільк.';
$lang['nopages']               = 'Простір назв пустий';
$lang['nosubns']               = 'Відсутні вкладені простори назв';
