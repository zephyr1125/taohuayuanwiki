<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'ovaj imenski prostor ne postoji';
$lang['subcats']               = 'Pod-imenski prostori:';
$lang['pagesinthiscat']        = 'Stranice u ovom imenskom prostoru:';
$lang['continued']             = 'nastavi...';
$lang['nopages']               = 'Nema stranica u ovom imenskom prostoru.';
$lang['nosubns']               = 'Nema pod-imenskih prostora.';
