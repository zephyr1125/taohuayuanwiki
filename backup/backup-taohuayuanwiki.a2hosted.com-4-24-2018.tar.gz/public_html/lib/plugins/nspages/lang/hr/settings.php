<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['cache']                 = 'Onemogući međuspremnik';
$lang['default_picture']       = 'Postavi svoju podrazumijevanu sliku';
$lang['toolbar_inserted_markup'] = 'Oznaka za umetnutu alatnu traku';
