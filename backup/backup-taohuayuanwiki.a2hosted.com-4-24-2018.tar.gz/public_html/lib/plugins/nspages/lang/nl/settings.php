<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author hugo smet <hugo.smet@scarlet.be>
 * @author Mark C. Prins <mprins@users.sf.net>
 */
$lang['cache']                 = 'uitschakelen tijdelijk geheugen (cache)';
$lang['toolbar_inserted_markup'] = 'Door de toolbarknop ingevoegde code';
