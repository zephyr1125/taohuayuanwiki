<?php
/**
 * Catalan language file
 *
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * @author     Joan <aseques@gmail.com>
 */
 
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'aquest namespace no existeix: ';
$lang['subcats']               = 'Subnamespaces:';
$lang['pagesinthiscat']        = 'Pàgines en aquest namespace:';
$lang['continued']             = ' cont.';
$lang['nopages']               = 'No hi ha pàgines en aquest namespace.';
$lang['nosubns']               = 'No hi ha subnamespaces.';
