<?php

$lang['cache'] = 'Disable the cache';
$lang['default_picture'] = 'Set your default picture';
$lang['toolbar_inserted_markup'] = 'Toolbar inserted markup';
