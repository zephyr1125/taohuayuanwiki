<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Tor Härnqvist <tor@harnqvist.se>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'följande namnrymd finns ej:';
$lang['subcats']               = 'Undernamnrymder:';
$lang['pagesinthiscat']        = 'Sidor i denna namnrymd:';
$lang['continued']             = ' forts.';
$lang['nopages']               = 'Inga sidor i denna namnrymd.';
$lang['nosubns']               = 'Inga undernamnrymder.';
