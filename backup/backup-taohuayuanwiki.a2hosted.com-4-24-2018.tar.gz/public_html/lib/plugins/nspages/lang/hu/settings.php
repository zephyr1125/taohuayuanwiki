<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Imre Nagy <crash2@freemail.hu>
 */

$lang['cache'] = 'Gyorsítótár kikapcsolása';
$lang['toolbar_inserted_markup'] = 'Eszköztárból beilleszthető kódrészlet';
