<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Imre Nagy <crash2@freemail.hu>
 */
$lang['encoding']              = 'utf-8';
$lang['direction']             = 'ltr';
$lang['doesntexist']           = 'A névtér nem létezik: ';
$lang['subcats']               = 'Al-névtér:';
$lang['pagesinthiscat']        = 'Oldalak a névtérben:';
$lang['continued']             = ' folyt.';
$lang['nopages']               = 'A névtér nem tartalmaz oldalakat.';
$lang['nosubns']               = 'Nincs al-névtér.';
