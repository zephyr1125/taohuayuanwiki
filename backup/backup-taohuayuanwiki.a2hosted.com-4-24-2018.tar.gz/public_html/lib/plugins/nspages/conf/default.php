<?php

$conf['toolbar_inserted_markup'] = '<nspages -h1 -subns -exclude:start>';
$conf['default_picture'] = '';
$conf['cache'] = 1;
