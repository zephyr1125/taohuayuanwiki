<?php

$meta['toolbar_inserted_markup'] = array('string');
$meta['default_picture'] = array('string');
$meta["cache"] = array("onoff");
