<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Errol <errol@hotmail.com>
 */
$lang['connectfail']           = '连接数据库失败';
$lang['userexists']            = '抱歉，用户名已被使用。';
$lang['writefail']             = '无法修改用户数据。请通知管理员';
