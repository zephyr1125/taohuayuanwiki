<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Bologö dödöu, no so zangoguna\'ö töi da\'a.';
