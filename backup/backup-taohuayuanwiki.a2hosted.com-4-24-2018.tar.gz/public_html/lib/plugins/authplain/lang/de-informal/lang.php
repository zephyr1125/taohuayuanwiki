<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author rnck <dokuwiki@rnck.de>
 */
$lang['userexists']            = 'Der Benutzername existiert leider schon.';
$lang['usernotexists']         = 'Entschuldigung, dieser Nutzer existiert nicht.';
$lang['writefail']             = 'Konnte Nutzer-Daten nicht modifizieren. Bitte informiere einen Admin.';
$lang['protected']             = 'Die Daten für den Nutzer %s sind geschützt und können nicht verändert oder gelöscht werden.';
