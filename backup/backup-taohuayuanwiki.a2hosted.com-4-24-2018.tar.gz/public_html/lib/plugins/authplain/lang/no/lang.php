<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Arne Hanssen <arne.hanssen@getmail.no>
 */
$lang['userexists']            = 'Det finnes allerede en konto med dette brukernavnet.';
$lang['usernotexists']         = 'Beklager, denne bruker fins ikke.';
$lang['writefail']             = 'Klarte ikke endre brukerdata. Dette bør meldes til wikiens administrator';
$lang['protected']             = 'Data for bruker %s er beskyttet og kan ikke endres eller slettes.';
