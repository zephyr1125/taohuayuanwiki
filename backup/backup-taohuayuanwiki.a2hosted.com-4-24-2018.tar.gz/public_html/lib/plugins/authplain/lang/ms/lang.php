<?php
/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 */
$lang['userexists']     = 'Maaf, nama pengguna yang dimasukkan telah diguna. Sila pilih nama yang lain.';
