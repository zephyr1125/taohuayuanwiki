<?php
/**
 * Korean language file
 *
 * @author Myeongjin <aranet100@gmail.com>
 */
$lang['fg'] = 'HTML hex 형식에서 차트에 대한 기본 색 (예 #ff0000). 선택 사항으로 네 번째에 알파 값을 제공하세요.';
$lang['bg'] = 'HTML hex 형식에서 차트에 대한 기본 색 (예 #efefef). 선택 사항으로 네 번째에 알파 값을 제공하세요.';
