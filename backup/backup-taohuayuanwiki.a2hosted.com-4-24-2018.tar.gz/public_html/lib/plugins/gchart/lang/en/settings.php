<?php
$lang['fg'] = 'Default color for charts in HTML hex format (eg. #ff0000). Optionally give an fourth alpha value.';
$lang['bg'] = 'Default color for charts in HTML hex format (eg. #efefef). Optionally give an fourth alpha value.';
