<?php

$meta['fg']     = array('string','_pattern' => '/^#[0-9a-f]{6}([0-9a-f][0-9a-f])?$/i');
$meta['bg']     = array('string','_pattern' => '/^#[0-9a-f]{6}([0-9a-f][0-9a-f])?$/i');

