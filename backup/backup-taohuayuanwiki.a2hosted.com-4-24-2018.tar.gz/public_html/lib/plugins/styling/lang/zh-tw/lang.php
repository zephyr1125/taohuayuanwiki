<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Liou, Jhe-Yu <lioujheyu@gmail.com>
 */
$lang['menu']                  = '模板風格設定';
$lang['error']                 = '抱歉，該模板不支持這個功能';
$lang['btn_preview']           = '預覽';
$lang['btn_save']              = '儲存';
$lang['btn_reset']             = '重設';
$lang['btn_revert']            = '將風格復原至模板預設值';
$lang['__text__']              = '主要文字顏色';
$lang['__background__']        = '主要背景顏色';
