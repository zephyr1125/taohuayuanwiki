<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Alfredo Silva <alfredo.silva@sky.com>
 */
$lang['js']['popup']           = 'Abrir como uma janela extra';
$lang['error']                 = 'Desculpe, este modelo não suporta esta funcionalidade.';
$lang['btn_preview']           = 'Pré-visualizar alterações';
$lang['btn_save']              = 'Guardar alterações';
$lang['btn_reset']             = 'Reiniciar alterações atuais';
$lang['__text__']              = 'Cor do texto principal';
