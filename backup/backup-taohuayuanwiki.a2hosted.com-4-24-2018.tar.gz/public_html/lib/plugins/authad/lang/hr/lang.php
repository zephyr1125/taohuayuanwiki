<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Davor Turkalj <turki.bsc@gmail.com>
 */
$lang['domain']                = 'Domena za prijavu';
$lang['authpwdexpire']         = 'Vaša lozinka će isteći za %d dana, trebate ju promijeniti.';
$lang['passchangefail']        = 'Ne mogu izmijeniti lozinku. Možda nije zadovoljen set pravila za lozinke?';
$lang['userchangefail']        = 'Greška pri promjeni atributa korisnika. Možda Vaš korisnik nema autorizacije da bi radio promjene?';
$lang['connectfail']           = 'Ne mogu se povezati s Active Directory poslužiteljem.';
