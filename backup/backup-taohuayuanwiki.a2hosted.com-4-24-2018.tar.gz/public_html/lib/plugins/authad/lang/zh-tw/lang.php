<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author June-Hao Hou <junehao@gmail.com>
 * @author syaoranhinata@gmail.com
 */
$lang['domain']                = '登入網域';
$lang['authpwdexpire']         = '您的密碼將在 %d 天內到期，請馬上更換新密碼。';
