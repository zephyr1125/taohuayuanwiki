<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Aivars Miška <allefm@gmail.com>
 */
$lang['domain']                = 'Iežurnālēšanās domēns';
$lang['authpwdexpire']         = 'Tavai parolei pēc %d dienām biegsies termiņš, tā drīzumā jānomaina.';
