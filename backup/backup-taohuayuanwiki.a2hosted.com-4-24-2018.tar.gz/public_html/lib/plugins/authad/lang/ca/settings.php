<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author controlonline.net <controlonline.net@gmail.com>
 */
$lang['account_suffix']        = 'El teu nom de compte. Ej.<code>@my.domain.org</code>';
$lang['base_dn']               = 'Nom base DN. Ej. <code>DC=my,DC=domain,DC=org</code>';
$lang['domain_controllers']    = 'Llista separada per coma dels controladors de domini. Ej.<code>DC=my,DC=domain,DC=org</code>';
