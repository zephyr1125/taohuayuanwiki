<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 * 
 * @author Menashe Tomer <menashesite@gmail.com>
 */
$lang['admin_password']        = 'סיסמת המשתמש המוזכן';
